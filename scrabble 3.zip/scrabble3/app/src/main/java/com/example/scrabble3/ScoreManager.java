package com.example.scrabble3;

import android.content.Context;
import android.content.SharedPreferences;

public class ScoreManager {
    private static final String SCORE_PREFS = "ScorePrefs";
    private static final String PLAYER1_SCORE_KEY = "Player1Score";
    private static final String PLAYER2_SCORE_KEY = "Player2Score";

    public static void saveScores(Context context, int player1Score, int player2Score) {
        // Сохраняем счет игроков в SharedPreferences
        SharedPreferences.Editor editor = context.getSharedPreferences(SCORE_PREFS, Context.MODE_PRIVATE).edit();
        editor.putInt(PLAYER1_SCORE_KEY, player1Score);
        editor.putInt(PLAYER2_SCORE_KEY, player2Score);
        editor.apply();
    }

    public static int[] getLastThreeScores(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(SCORE_PREFS, Context.MODE_PRIVATE);
        int[] scores = new int[3];
        scores[0] = prefs.getInt(PLAYER1_SCORE_KEY, 0);
        scores[1] = prefs.getInt(PLAYER2_SCORE_KEY, 0);
        scores[2] = prefs.getInt("PrevScore", 0);
        return scores;
    }

    public static int getPlayer1Score(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(SCORE_PREFS, Context.MODE_PRIVATE);
        return prefs.getInt(PLAYER1_SCORE_KEY, 0);
    }

    public static int getPlayer2Score(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(SCORE_PREFS, Context.MODE_PRIVATE);
        return prefs.getInt(PLAYER2_SCORE_KEY, 0);
    }
}