package com.example.scrabble3;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
public class DatabaseHelper extends SQLiteOpenHelper {
    private static String DB_NAME = "words-russian-nouns.sql"; // Название вашей базы данных
    private SQLiteDatabase mDataBase;
    private final Context mContext;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, 1);
        this.mContext = context;
        copyDatabase();
    }

    private void copyDatabase() {
        try {
            InputStream mInput = mContext.getAssets().open(DB_NAME);
            String outFileName = mContext.getDatabasePath(DB_NAME).getPath();
            OutputStream mOutput = new FileOutputStream(outFileName);
            byte[] mBuffer = new byte[1024];
            int mLength;
            while ((mLength = mInput.read(mBuffer)) > 0) {
                mOutput.write(mBuffer, 0, mLength);
            }
            mOutput.flush();
            mOutput.close();
            mInput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void executeSQLScript(SQLiteDatabase database, Context context, String scriptAssetName) {
        try {
            InputStream inputStream = context.getAssets().open(scriptAssetName);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                database.execSQL(line);
            }

            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        copyDatabase();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    // Далее, вам потребуется обычные методы для работы с базой данных.
}
