package com.example.scrabble3;

public class ScoresAdapter {
}
