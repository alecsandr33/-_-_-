package com.example.scrabble3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE = 1;

    private int totalScorePlayer1 = 0;
    private int totalScorePlayer2 = 0;
    private Button rulesButton;
    private TextView player1ScoreTextView;
    private TextView player2ScoreTextView;
    private Button startGameButton;
    private Button showScoresButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         rulesButton = findViewById(R.id.rulesButton);
        player1ScoreTextView = findViewById(R.id.player1ScoreTextView);
        player2ScoreTextView = findViewById(R.id.player2ScoreTextView);
        startGameButton = findViewById(R.id.startSecondActivityButton);
        showScoresButton = findViewById(R.id.showScoresButton);
        LoadingTask loadingTask = new LoadingTask(this);
        loadingTask.execute();
        rulesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Отображение диалогового окна с правилами
                showRulesDialog();
            }
        });

        showScoresButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showScoresDialog();
            }
        });
        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Запускаем SecondActivity при нажатии кнопки
                startActivityForResult(new Intent(MainActivity.this, SecondActivity.class), REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                totalScorePlayer1 = data.getIntExtra("player1Score", 0);
                totalScorePlayer2 = data.getIntExtra("player2Score", 0);
                // Обновляем отображение счета игроков

            }
        }
    }

    private void updateScoreDisplay() {
        player1ScoreTextView.setText("Счет игрока 1: " + totalScorePlayer1);
        player2ScoreTextView.setText("Счет игрока 2: " + totalScorePlayer2);
    }
    private void showScoresDialog() {
        // Создать диалоговое окно
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.scores_dialog, null);
        dialogBuilder.setView(dialogView);

        // Получить TextView для отображения счетов
        TextView scoresTextView = dialogView.findViewById(R.id.scoresTextView);

        // Создайте экземпляр ScoreDatabaseHelper
        ScoreDatabaseHelper dbHelper = new ScoreDatabaseHelper(this);

        // Получите базу данных для чтения
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Выполните SQL-запрос для получения счетов игроков
        Cursor cursor = db.query(
                ScoreDatabaseHelper.TABLE_SCORES,
                new String[] {
                        ScoreDatabaseHelper.COLUMN_PLAYER_1_SCORE,
                        ScoreDatabaseHelper.COLUMN_PLAYER_2_SCORE
                },
                null,
                null,
                null,
                null,
                null
        );

        StringBuilder scoresText = new StringBuilder();

        // Переберите записи и добавьте их к scoresText
        while (cursor.moveToNext()) {
            int player1ScoreIndex = cursor.getColumnIndex(ScoreDatabaseHelper.COLUMN_PLAYER_1_SCORE);
            int player2ScoreIndex = cursor.getColumnIndex(ScoreDatabaseHelper.COLUMN_PLAYER_2_SCORE);

            // Проверьте, существует ли столбец перед извлечением данных
            if (player1ScoreIndex != -1 && player2ScoreIndex != -1) {
                int player1Score = cursor.getInt(player1ScoreIndex);
                int player2Score = cursor.getInt(player2ScoreIndex);
                scoresText.append("Игрок 1: ").append(player1Score).append(" - Игрок 2: ").append(player2Score).append("\n");
            }
        }

        // Закройте курсор и базу данных
        cursor.close();
        db.close();

        // Установите текст в TextView
        scoresTextView.setText(scoresText.toString());

        // Добавьте кнопку для закрытия диалогового окна
        dialogBuilder.setPositiveButton("Закрыть", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        // Покажите диалоговое окно
        AlertDialog dialog = dialogBuilder.create();
        dialog.show();
    }

    private void showRulesDialog() {
        // Создайте диалоговое окно
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.rules_dialog);

        // Настройте размеры диалогового окна
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(lp);
        TextView rulesTextView = dialog.findViewById(R.id.rulesTextview);
        rulesTextView.setText("Игровое поле состоит из 15×15, то есть 225 квадратов, на которых участники игры выкладывают буквы, составляя тем самое главное слово. В начале игры каждый игрок получает 7 случайных букв (всего их в игре 104, в « «Эрудите» — 131). Через центральные ячейки игрового поля по горизонтали или вертикали выкладывается первое слово, затем следующий игрок может добавить слово «на пересечение» из своих букв. Слова складываются либо слева направо, либо сверху вниз. больше слов на основе существующих костяшек с буквами тем самым набрать большее количество очков.");

        // Настройте кнопку для закрытия диалогового окна
        Button closeButton = dialog.findViewById(R.id.closeButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        // Отобразите диалоговое окно
        dialog.show();
    }
}



