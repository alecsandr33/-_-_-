package com.example.scrabble3;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class SecondActivity extends AppCompatActivity {
    private View.OnTouchListener tileTouchListener1; // Объявляем tileTouchListener1
    private View.OnTouchListener tileTouchListener2; // Объявляем tileTouchListener2
    private Button replaceLettersButton;
    GridLayout tilesLayout1;
    GridLayout tilesLayout2;

    private Button checkButton;
    private TileTouchListener tileTouchListener = new TileTouchListener();
    ArrayList<Integer> Players = new ArrayList<>();
    public boolean isSelectionMode;
    int totalScorePlayer1 = 0;
    int totalScorePlayer2 = 0;
    int skipIndicator = 0;
    int a = 0;
    private Button skipButton;
    private TextView score1TextView;
    private TextView words_textview;
    private TextView scoreTextView;
    private TextView tile;
    ArrayList<String> PlayersTiles = new ArrayList<>();
    ArrayList<String> deletedLetters = new ArrayList<>();
    ArrayList<String> alreadyFoundWords = new ArrayList<>();
    ArrayList<String> unDoubleWords = new ArrayList<>();
    ArrayList<String> doubleWords = new ArrayList<>();
    ArrayList<TextView> wordTiles = new ArrayList<>();
    ArrayList<TextView> movedTiles = new ArrayList<>();
    private TextView[][] tilesArrayBlue = new TextView[15][15];
    private TextView[][] tilesArrayDarkBlue = new TextView[15][15];
    private TextView[][] tilesArrayPink = new TextView[15][15];
    private TextView[][] tilesArrayRed = new TextView[15][15];
    private static final int BOARD_SIZE = 15;
    private static final int TILE_COUNT = 7;
    private int totalScore = 0;
    private TextView score2TextView;
    private GridLayout gridLayout;
    private List<TextView> tiles;
    private List<TextView> letterTiles;
    private Random random;
    private List<TextView> selectedTiles = new ArrayList<>();
    private TextView draggedTile;
    private TextView wordsTextView;
    private DatabaseHelper databaseHelper;
    private SQLiteDatabase database;
    private static final String DATABASE_NAME = "words-russian-nouns.sql";
    private static final int DATABASE_VERSION = 1;
    String fileName = "C:\\ATI\\Support\\9-11_vista64_win7_64_dd_ccc_wdm_enu\\Driver\\scrabble3\\app\\src\\main\\assets\\singular.txt";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




        setContentView(R.layout.secondactivity_main);
        Players.add(1);
        Players.add(2);
        gridLayout = findViewById(R.id.grid_layout);
        tiles = new ArrayList<>();
        letterTiles = new ArrayList<>();
        random = new Random();


        scoreTextView = findViewById(R.id.scoreTextView);
        words_textview = findViewById(R.id.words_textview);
        score1TextView = findViewById(R.id.score1TextView);
         score2TextView = findViewById(R.id.score2TextView);
        tilesLayout1 = findViewById(R.id.tiles_layout);
        tilesLayout2 = findViewById(R.id.tiles_layout_2);
        tilesLayout1.setVisibility(View.VISIBLE);
        tilesLayout2.setVisibility(View.GONE);
        replaceLettersButton = findViewById(R.id.replaceButton);
        checkButton = findViewById(R.id.check_button);
        Button yesButton = findViewById(R.id.yesButton);
        Button noButton = findViewById(R.id.noButton);
        skipButton = findViewById(R.id.skipButton);
        checkButton.setVisibility(View.INVISIBLE);
        // Создаем поле 15x15
        score1TextView.setText("Счёт игрока 1 : 0");
        score2TextView.setText("Счёт игрока 2 : 0");
        createBoard();

        // Добавляем 7 рандомных фишек рядом с полем
        addRandomTiles();
        addRandomTiles2(tilesLayout2);


               View.OnTouchListener tileTouchListener1 = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        TextView tile1 = (TextView) v; // Получаем фишку, на которой произошло касание
                        // Обработка нажатия
                        if (!selectedTiles.contains(tile1)) {
                            // Если фишка не выбрана, добавьте ее в selectedTiles
                            selectedTiles.add(tile1);
                            // Измените фон фишки на tile_background_yellow
                            tile1.setBackgroundResource(R.drawable.tile_background_yellow);
                        } else {
                            // Если фишка уже выбрана, удалите ее из selectedTiles
                            selectedTiles.remove(tile1);
                            // Верните оригинальный фон фишки
                            tile1.setBackgroundResource(R.drawable.tile_background_highlighted);
                        }
                        return true;
                }
                return false;
            }
        };
        View.OnTouchListener tileTouchListener2 = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        TextView tile2 = (TextView) v;
                        // Обработка нажатия
                        if (!selectedTiles.contains(tile2)) {
                            // Если фишка не выбрана, добавьте ее в selectedTiles
                            selectedTiles.add(tile2);
                            // Измените фон фишки на tile_background_yellow
                            tile2.setBackgroundResource(R.drawable.tile_background_yellow);
                        } else {
                            // Если фишка уже выбрана, удалите ее из selectedTiles
                            selectedTiles.remove(tile2);
                            // Верните оригинальный фон фишки
                            tile2.setBackgroundResource(R.drawable.tile_background_highlighted);
                        }
                        return true;
                }
                return false;
            }
        };
        replaceLettersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView score1TextView = findViewById(R.id.score1TextView);
                TextView score2TextView = findViewById(R.id.score2TextView);
                // Скрываем необходимые элементы
                words_textview.setVisibility(View.INVISIBLE);
                score1TextView.setVisibility(View.INVISIBLE);
                score2TextView.setVisibility(View.INVISIBLE);
                replaceLettersButton.setVisibility(View.INVISIBLE);
                checkButton.setVisibility(View.INVISIBLE);
                // Показываем кнопки "Да" и "Нет"
                yesButton.setVisibility(View.VISIBLE);
                noButton.setVisibility(View.VISIBLE);
                for (int i = 0; i < tilesLayout1.getChildCount(); i++) {
                    View tile = tilesLayout1.getChildAt(i);
                    tile.setOnTouchListener(tileTouchListener1);
                }
                for (int i = 0; i < tilesLayout2.getChildCount(); i++) {
                    View tile = tilesLayout2.getChildAt(i);
                    tile.setOnTouchListener(tileTouchListener2);
                }
                // Обработка нажатия кнопки "Нет"
                noButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for (TextView tile : selectedTiles) {
                            tile.setBackgroundResource(R.drawable.tile_background_highlighted);
                        }
                        selectedTiles.clear();
                        for (int i = 0; i < tilesLayout1.getChildCount(); i++) {
                            View tile = tilesLayout1.getChildAt(i);
                            tile.setOnTouchListener(tileTouchListener);
                        }
                        for (int i = 0; i < tilesLayout2.getChildCount(); i++) {
                            View tile = tilesLayout2.getChildAt(i);
                            tile.setOnTouchListener(tileTouchListener);
                        }

                        words_textview.setVisibility(View.VISIBLE);
                        score1TextView.setVisibility(View.VISIBLE);
                        score2TextView.setVisibility(View.VISIBLE);
                        replaceLettersButton.setVisibility(View.VISIBLE);
                        checkButton.setVisibility(View.VISIBLE);
                        // Скрываем кнопки "Да" и "Нет"
                        yesButton.setVisibility(View.GONE);
                        noButton.setVisibility(View.GONE);
                        isSelectionMode = false;
                        checkButton.setVisibility(View.INVISIBLE);
                    }
                });
                yesButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for (TextView tile : selectedTiles) {
                            deletedLetters.add(tile.getText().toString()); // Добавляем букву в список deletedLetters
                            tile.setText(null); // Удаляем букву с фишки, установив текст в null
                            tile.setBackgroundResource(R.drawable.tile_background_highlighted); // Восстанавливаем исходный цвет фишки
                        }

                        skipIndicator += 1;
                        if(skipIndicator == 10){
                            showEndDialog();
                        }
                        checkButton.setVisibility(View.INVISIBLE);
                        selectedTiles.clear(); // Очищаем список выбранных фишек
                        for (String letter: deletedLetters) {
                            lettersList.add(letter);
                        }
                        deletedLetters.clear();
                        for (int i = 0; i < tilesLayout1.getChildCount(); i++) {
                            View tile = tilesLayout1.getChildAt(i);
                            tile.setOnTouchListener(tileTouchListener);
                        }
                        for (int i = 0; i < tilesLayout2.getChildCount(); i++) {
                            View tile = tilesLayout2.getChildAt(i);
                            tile.setOnTouchListener(tileTouchListener);
                        }
                        // Восстанавливаем видимость элементов
                        words_textview.setVisibility(View.VISIBLE);
                        score1TextView.setVisibility(View.VISIBLE);
                        score2TextView.setVisibility(View.VISIBLE);
                        replaceLettersButton.setVisibility(View.VISIBLE);
                        checkButton.setVisibility(View.INVISIBLE);
                        // Скрываем кнопки "Да" и "Нет"
                        yesButton.setVisibility(View.GONE);
                        noButton.setVisibility(View.GONE);
                        findWords();

                        fillEmptyTilesWithRandomLetters();
                        doubleWords.clear();
                        unDoubleWords.clear();
                    }
                });
            }
        });
        skipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkButton.setVisibility(View.INVISIBLE);
                if (skipIndicator == 2) {
                    showEndDialog();
                } else
                {findWords();
                    skipIndicator += 1;}
            }
        });
        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(findDoubleWords())) {
                    if (lettersList.isEmpty()) {
                        replaceLettersButton.setVisibility(View.INVISIBLE);
                        skipButton.setVisibility(View.VISIBLE);

                    } else {
                        checkButton.setVisibility(View.INVISIBLE);
                        replaceLettersButton.setVisibility(View.VISIBLE);
                    }
                    skipIndicator = 0;

                    unDoubleWords.clear();
                    movedTiles.clear();
                    PlayersTiles.clear();
                    findWords();
                    fillEmptyTilesWithRandomLetters();
                    int currentPlayer = Players.get(0);
                    if (currentPlayer == 1) {
                        // Увеличиваем счет первого игрока
                        tilesLayout1.setVisibility(View.VISIBLE);
                        tilesLayout2.setVisibility(View.GONE);
                    } else {
                        tilesLayout2.setVisibility(View.VISIBLE);
                        tilesLayout1.setVisibility(View.GONE);
                    }
                } else {
                showDoubleWordDialog(doubleWords);
                }
                doubleWords.clear();
                unDoubleWords.clear();

            }
        });

        wordsTextView = findViewById(R.id.words_textview);
    }

    private void createBoard() {
        gridLayout.setColumnCount(BOARD_SIZE);
        gridLayout.setRowCount(BOARD_SIZE);

        for (int i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
            TextView tile = createTile();
            gridLayout.addView(tile);
            tiles.add(tile);


        }

        addToTilesArrayBlue(0, 3);
        addToTilesArrayBlue(0, 11);
        addToTilesArrayBlue(2, 6);
        addToTilesArrayBlue(2, 8);
        addToTilesArrayBlue(3, 0);
        addToTilesArrayBlue(3, 7);
        addToTilesArrayBlue(3, 14);
        addToTilesArrayBlue(6, 2);
        addToTilesArrayBlue(6, 6);
        addToTilesArrayBlue(6, 8);
        addToTilesArrayBlue(6, 12);
        addToTilesArrayBlue(7, 3);
        addToTilesArrayBlue(7, 11);
        addToTilesArrayBlue(8, 2);
        addToTilesArrayBlue(8, 6);
        addToTilesArrayBlue(8, 8);
        addToTilesArrayBlue(8, 12);
        addToTilesArrayBlue(11, 0);
        addToTilesArrayBlue(11, 7);
        addToTilesArrayBlue(11, 14);
        addToTilesArrayBlue(12, 6);
        addToTilesArrayBlue(12, 8);
        addToTilesArrayBlue(14, 3);
        addToTilesArrayBlue(14, 11);
        addToTilesArray(0, 0, tilesArrayRed);
        addToTilesArray(0, 7, tilesArrayRed);
        addToTilesArray(0, 14, tilesArrayRed);
        addToTilesArray(7, 0, tilesArrayRed);
        addToTilesArray(7, 14, tilesArrayRed);
        addToTilesArray(14, 0, tilesArrayRed);
        addToTilesArray(14, 7, tilesArrayRed);
        addToTilesArray(14, 14, tilesArrayRed);
        addToTilesArray(1, 1, tilesArrayPink);
        addToTilesArray(2, 2, tilesArrayPink);
        addToTilesArray(3, 3, tilesArrayPink);
        addToTilesArray(4, 4, tilesArrayPink);
        addToTilesArray(13, 1, tilesArrayPink);
        addToTilesArray(12, 2, tilesArrayPink);
        addToTilesArray(11, 3, tilesArrayPink);
        addToTilesArray(10, 4, tilesArrayPink);
        addToTilesArray(4, 10, tilesArrayPink);
        addToTilesArray(3, 11, tilesArrayPink);
        addToTilesArray(2, 12, tilesArrayPink);
        addToTilesArray(1, 13, tilesArrayPink);
        addToTilesArray(10, 10, tilesArrayPink);
        addToTilesArray(11, 11, tilesArrayPink);
        addToTilesArray(12, 12, tilesArrayPink);
        addToTilesArray(13, 13, tilesArrayPink);
        addToTilesArray(5, 1, tilesArrayDarkBlue);
        addToTilesArray(9, 1, tilesArrayDarkBlue);
        addToTilesArray(1, 5, tilesArrayDarkBlue);
        addToTilesArray(13, 5, tilesArrayDarkBlue);
        addToTilesArray(5, 5, tilesArrayDarkBlue);
        addToTilesArray(9, 5, tilesArrayDarkBlue);
        addToTilesArray(1, 9, tilesArrayDarkBlue);
        addToTilesArray(5, 9, tilesArrayDarkBlue);
        addToTilesArray(9, 9, tilesArrayDarkBlue);
        addToTilesArray(13, 9, tilesArrayDarkBlue);
        addToTilesArray(5, 13, tilesArrayDarkBlue);
        addToTilesArray(9, 13, tilesArrayDarkBlue);
        for (int i = 0; i < tilesArrayBlue.length; i++) {
            for (int j = 0; j < tilesArrayBlue[i].length; j++) {

                if (tilesArrayBlue[i][j] != null) {
                    tilesArrayBlue[i][j].setBackgroundResource(R.drawable.tile_background_blue);}
            }

        }
        for (int i = 0; i < tilesArrayRed.length; i++) {
            for (int j = 0; j < tilesArrayRed[i].length; j++) {

                if (tilesArrayRed[i][j] != null) {
                    tilesArrayRed[i][j].setBackgroundResource(R.drawable.tile_background_red);}
            }

        }
        for (int i = 0; i < tilesArrayPink.length; i++) {
            for (int j = 0; j < tilesArrayPink[i].length; j++) {

                if (tilesArrayPink[i][j] != null) {
                    tilesArrayPink[i][j].setBackgroundResource(R.drawable.tile_background_pink);}
            }

        }
        for (int i = 0; i < tilesArrayDarkBlue.length; i++) {
            for (int j = 0; j < tilesArrayDarkBlue[i].length; j++) {

                if (tilesArrayDarkBlue[i][j] != null) {
                    tilesArrayDarkBlue[i][j].setBackgroundResource(R.drawable.tile_background_darkblue);}
            }

        }



    }
    public void addToTilesArray(int i, int j, TextView[][] tilesArray) {
        if (tilesArray != null && i >= 0 && i < tilesArray.length && j >= 0 && j < tilesArray[i].length) {
            tilesArray[i][j] = (TextView) gridLayout.getChildAt(i * gridLayout.getColumnCount() + j);
        }
    }
    public  void addToTilesArrayBlue(int i, int j) {
        if ( tilesArrayBlue != null && i >= 0 && i < tilesArrayBlue.length && j >= 0 && j < tilesArrayBlue[i].length) {
            tilesArrayBlue[i][j] = (TextView) gridLayout.getChildAt(i * gridLayout.getColumnCount() + j);
        }
    }


    private SQLiteDatabase openDatabase() {
        try {
            String dbPath = getDatabasePath("words-russian-nouns.sql").getPath();

            SQLiteDatabase db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY);

            // Установите максимальный размер базы данных
            db.setMaximumSize(5 * 1024 * 1024); // Например, установите максимальный размер на 4 мегабайта

            return db;
        } catch (SQLiteException e) {
            e.printStackTrace();
            return null;
        }
    }
    private boolean isWordIntersecting(String foundWord, List<String> existingWords) {
        for (String existingWord : existingWords) {
            for (int i = 0; i < existingWord.length(); i++) {
                char letter = existingWord.charAt(i);
                if (foundWord.indexOf(letter) != -1) {
                    // Найден пересекающийся символ
                    return true;
                }
            }
        }
        return false;
    }
    private boolean isTileInTilesArray(TextView[][] tilesArray, TextView tile) {
        for (int i = 0; i < tilesArray.length; i++) {
            for (int j = 0; j < tilesArray[i].length; j++) {
                if (tilesArray[i][j] == tile) {
                    return true; // Клетка принадлежит массиву
                }
            }
        }
        return false; // Клетка не принадлежит массиву
    }
    private boolean checkWords(List<String> foundWords, List<String> randomWords) {
        for (String foundWord : foundWords) {
            if (!randomWords.contains(foundWord)) {
                // Найдено несовпадающее слово, выводим его
                System.out.println("Несовпадающее слово: " + foundWord);
                return false;
            }
        }
        return true;
    }

    private void fillEmptyTilesWithRandomLetters() {
        for (TextView tile : letterTiles) {
            if (tile.getText() == null || tile.getText().toString().isEmpty()) {
                if(!(lettersList.isEmpty())){
                    String randomLetter = getRandomLetter();
                    tile.setText(randomLetter);
                }
            }
        }
    }
    @SuppressLint("ClickableViewAccessibility")
    private TextView createTile() {
        TextView tile = new TextView(this);
        GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
        layoutParams.width = 0;
        layoutParams.height = GridLayout.LayoutParams.WRAP_CONTENT;
        layoutParams.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        tile.setLayoutParams(layoutParams);
        tile.setPadding(16, 16, 16, 16);
        tile.setBackgroundResource(R.drawable.tile_background);
        tile.setOnTouchListener(new TileTouchListener());
        tile.setOnDragListener(new TileDragListener());
        return tile;
    }
    @SuppressLint("ClickableViewAccessibility")
    private TextView createWhiteTile() {
        TextView tile = new TextView(this);
        GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
        layoutParams.width = 0;
        layoutParams.height = GridLayout.LayoutParams.WRAP_CONTENT;
        layoutParams.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        tile.setLayoutParams(layoutParams);
        tile.setPadding(16, 16, 16, 16);
        tile.setBackgroundResource(R.drawable.tile_background_highlighted);
        tile.setOnTouchListener(new TileTouchListener());
        tile.setOnDragListener(new TileDragListener());
        return tile;
    }
    public static boolean searchWordInFile(String word, String filePath) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;

            while ((line = reader.readLine()) != null) {
                // Удаляем пробелы и приводим к нижнему регистру для сравнения без учета регистра
                String cleanedLine = line.trim().toLowerCase();

                // Если найдено совпадение, возвращаем true
                if (cleanedLine.equals(word.toLowerCase())) {
                    reader.close();
                    return true;
                }
            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Если совпадений не найдено, возвращаем false
        return false;
    }

    private int calculateScore(String word) {
        int score = 0;
          Set<Character> doubledLetters = new HashSet<>();
        Set<Character> tripledLetters = new HashSet<>();
        for (char letter : word.toCharArray()) {
            char uppercaseLetter = Character.toUpperCase(letter);
            int letterScore = 0;
            switch (uppercaseLetter) {
                case 'А':
                case 'Н':
                case 'О':
                case 'Е':
                case 'И':
                    letterScore += 1;
                    break;
                case 'К':
                case 'Л':
                case 'В':
                case 'М':
                case 'Д':
                case 'Р':
                case 'Т':
                case 'П':
                case 'С':
                case 'Й':
                    letterScore += 2;
                    break;
                case 'Х':
                case 'Ч':
                case 'Ы':
                case 'Ж':
                case 'Ь':
                case 'З':
                    letterScore += 5;
                    break;
                case 'Б':
                case 'Г':
                case 'У':
                case 'Я':
                    letterScore += 3;
                    break;
                case 'Ц':
                case 'Ш':
                case 'Щ':
                case 'Э':
                case 'Ъ':
                case 'Ю':
                case 'Ф':
                    letterScore += 10;
                    break;
            }
            if (!doubledLetters.contains(uppercaseLetter) && isLetterOnTile(letter, tilesArrayBlue)) {
                // Если буква не содержится в doubledLetters и она находится на синей плитке,
                // то вы удваиваете очки и добавляете эту букву в множество doubledLetters.
                letterScore *= 2;
                doubledLetters.add(uppercaseLetter);
            }
            // Check if the letter is on a dark blue tile and if it's the special letter
            if (!tripledLetters.contains(uppercaseLetter) && isLetterOnTile(letter, tilesArrayDarkBlue)) {
                // Аналогично, если буква не содержится в tripledLetters и она находится на тёмно-синей плитке,
                // то вы утраиваете очки и добавляете эту букву в множество tripledLetters.
                letterScore *= 3;
                tripledLetters.add(uppercaseLetter);
            }
            score += letterScore;

        }
        return score;
    }
    private boolean isLetterOnTile(char letter, TextView[][] tileArray) {
        for (int i = 0; i < tileArray.length; i++) {
            for (int j = 0; j < tileArray[i].length; j++) {
                if (tileArray[i][j] != null) {
                    String tileText = tileArray[i][j].getText().toString();
                    if (tileText.equalsIgnoreCase(String.valueOf(letter))) {
                        return true; // The letter is on a tile in the specified tileArray
                    }
                }
            }
        }
        return false; // The letter is not on a tile in the specified tileArray
    }

    private void addRandomTiles2(GridLayout tilesLayout) {
        tilesLayout.setColumnCount(TILE_COUNT);

        for (int i = 0; i < TILE_COUNT; i++) {
            String letter = getRandomLetter();
            TextView tile = createWhiteTile();
            tile.setText(letter);
            letterTiles.add(tile);
            tilesLayout.addView(tile);
        }
    }


    private void addRandomTiles() {
        GridLayout tilesLayout = findViewById(R.id.tiles_layout);
        tilesLayout.setColumnCount(TILE_COUNT);

        for (int i = 0; i < TILE_COUNT; i++) {
            String letter = getRandomLetter();
            TextView tile = createWhiteTile();
            tile.setText(letter);
            letterTiles.add(tile);
            tilesLayout.addView(tile);
        }
    }
    private ArrayList<String> lettersList = new ArrayList<>(Arrays.asList(
            "А", "А", "А", "А", "А", "А", "А", "А", "А", "А",
            "Б", "Б", "Б",
            "В", "В", "В", "В", "В",
            "Г", "Г", "Г",
            "Д", "Д", "Д", "Д", "Д",
            "Е", "Е", "Е", "Е", "Е", "Е", "Е", "Е", "Е",
            "Ж", "Ж",
            "З", "З",
            "И", "И", "И", "И", "И", "И", "И", "И",
            "Й", "Й", "Й", "Й",
            "К", "К", "К", "К", "К", "К",
            "Л", "Л", "Л", "Л",
            "М", "М", "М", "М", "М",
            "Н", "Н", "Н", "Н", "Н", "Н", "Н", "Н",
            "О", "О", "О", "О", "О", "О", "О", "О", "О", "О",
            "П", "П", "П", "П", "П", "П",
            "Р", "Р", "Р", "Р", "Р", "Р",
            "С", "С", "С", "С", "С", "С",
            "Т", "Т", "Т", "Т", "Т",
            "У", "У", "У",
            "Ф",
            "Х", "Х",
            "Ц",
            "Ч", "Ч",
            "Ш",
            "Щ",
            "Ъ",
            "Ы", "Ы",
            "Ь", "Ь",
            "Э",
            "Ю",
            "Я", "Я", "Я"
    ));


    private String getRandomLetter() {


        int randomIndex = (int) (Math.random() * lettersList.size());
        String letter = lettersList.get(randomIndex);

        // Удалить использованную букву из списка
        lettersList.remove(randomIndex);

        return letter;
    }

    private void showDoubleWordDialog(List<String > doubleWords) {

        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.doublewordfound_dialog);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(lp);

        TextView doubleWordDialogMessageTextView = dialog.findViewById(R.id.doubleWordDialogMessageTextView);
        doubleWordDialogMessageTextView.setText("Найдены повторяющиеся слова");
        // Убирает фон окна
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT); // Растягивает окно на весь экран
        Button doubleWordOkButton = dialog.findViewById(R.id.doubleWordOkButton);
        StringBuilder stringBuilder = new StringBuilder();
        TextView DoubleWord = dialog.findViewById(R.id.DoubleWord);

        for (String item : doubleWords) {
            stringBuilder.append(item).append("\n"); // Добавить каждый элемент и перевод строки
        }

        String allElements = stringBuilder.toString();
        DoubleWord.setText(allElements);
        doubleWordOkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss(); // Закрыть диалоговое окно при нажатии кнопки "ОК"
            }
        });

        dialog.show();
    }
    private boolean findDoubleWords() {
        int gridSize = gridLayout.getRowCount();
        boolean foundDoubleWords = false;
        // Поиск слов по горизонтали
        for (int i = 0; i < gridSize; i++) {
            StringBuilder wordBuilder = new StringBuilder();
            for (int j = 0; j < gridSize; j++) {
                TextView tile = (TextView) gridLayout.getChildAt(i * gridSize + j);
                String letter = tile.getText().toString().trim();
                if (!letter.isEmpty()) {
                    wordBuilder.append(letter);

                } else {
                    if (wordBuilder.length() > 1) {
                        unDoubleWords.add(wordBuilder.toString());
                    }
                    wordBuilder.setLength(0);

                }
            }
            if (wordBuilder.length() > 1) {
                unDoubleWords.add(wordBuilder.toString());
            }
        }
        // Поиск слов по вертикали
        for (int j = 0; j < gridSize; j++) {
            StringBuilder wordBuilder = new StringBuilder();
            for (int i = 0; i < gridSize; i++) {
                TextView tile = (TextView) gridLayout.getChildAt(i * gridSize + j);
                String letter = tile.getText().toString().trim();
                if (!letter.isEmpty()) {
                    wordBuilder.append(letter);

                } else {
                    if (wordBuilder.length() > 1) {
                        unDoubleWords.add(wordBuilder.toString());
                    }
                    wordBuilder.setLength(0);
                }
            }
            if (wordBuilder.length() > 1) {
                unDoubleWords.add(wordBuilder.toString());
            }
        }
        for (String word : unDoubleWords) {
            int wordCount = Collections.frequency(unDoubleWords, word);

                if (wordCount >= 2) {
                    doubleWords.add(word);

                }






            }
        if (!(doubleWords.isEmpty())) {
            foundDoubleWords = true;
        }
        unDoubleWords.clear();
        return foundDoubleWords;
    }

    private List<String> findWords() {
        List<String> foundWords = new ArrayList<>();
        int gridSize = gridLayout.getRowCount();
        int currentPlayer = Players.get(0);
        // Поиск слов по горизонтали
        for (int i = 0; i < gridSize; i++) {
            StringBuilder wordBuilder = new StringBuilder();
            for (int j = 0; j < gridSize; j++) {
                TextView tile = (TextView) gridLayout.getChildAt(i * gridSize + j);
                String letter = tile.getText().toString().trim();
                if (!letter.isEmpty()) {
                    wordBuilder.append(letter);
                    wordTiles.add(tile);
                } else {
                    if (wordBuilder.length() > 1) {
                        foundWords.add(wordBuilder.toString());
                        unDoubleWords.add(wordBuilder.toString());

                    }
                    wordBuilder.setLength(0);

                }
            }
            if (wordBuilder.length() > 1) {
                foundWords.add(wordBuilder.toString());
                unDoubleWords.add(wordBuilder.toString());
            }
        }
        // Поиск слов по вертикали
        for (int j = 0; j < gridSize; j++) {
            StringBuilder wordBuilder = new StringBuilder();
            for (int i = 0; i < gridSize; i++) {
                TextView tile = (TextView) gridLayout.getChildAt(i * gridSize + j);
                String letter = tile.getText().toString().trim();
                if (!letter.isEmpty()) {
                    wordBuilder.append(letter);
                    wordTiles.add(tile);
                } else {
                    if (wordBuilder.length() > 1) {
                        foundWords.add(wordBuilder.toString());
                        unDoubleWords.add(wordBuilder.toString());
                    }
                    wordBuilder.setLength(0);
                }
            }
            if (wordBuilder.length() > 1) {
                foundWords.add(wordBuilder.toString());
                unDoubleWords.add(wordBuilder.toString());
            }
        }

        StringBuilder sb = new StringBuilder();
        for (String word : foundWords) {
            if (!alreadyFoundWords.contains(word)) {
                int wordScore = calculateScore(word); // Рассчет очков для каждого слова
                if (isWordDouble(word, tilesArrayPink)) {
                    wordScore *= 2;
                }
                if (isWordTripled(word, tilesArrayRed)) {
                    wordScore *= 3;
                }
                sb.append(word).append(" (").append(wordScore).append(" очков)").append("\n");
                alreadyFoundWords.add(word); // Добавляем слово в alreadyFoundWords, если оно еще не было найдено
                totalScore += wordScore; // Обновление общего счета
                if (currentPlayer == 1) {
                    // Увеличиваем счет первого игрока
                    totalScorePlayer1 += wordScore;
                } else if (currentPlayer == 2) {
                    // Увеличиваем счет второго игрока
                    totalScorePlayer2 += wordScore;

                }
            }
        }
        Players.add(Players.remove(0));
        showPlayerTurnDialog(currentPlayer);
        TextView score2TextView = findViewById(R.id.score2TextView);
        score2TextView.setText("Счёт игрока 2 : " + totalScorePlayer2);
        TextView score1TextView = findViewById(R.id.score1TextView);
        score1TextView.setText("Счёт игрока 1 : " + totalScorePlayer1);
        // Вывод найденных слов в TextView
        TextView foundWordsTextView = findViewById(R.id.words_textview);
        foundWordsTextView.setText(sb.toString());
        return foundWords;
    }




    private boolean isTileInWordTiles(TextView tile, ArrayList<TextView> wordTiles) {
        return wordTiles.contains(tile);
    }
    private boolean isWordTripled(String word, TextView[][] tilesArrayRed) {
        for (int i = 0; i < word.length(); i++) {
            char letter = Character.toUpperCase(word.charAt(i));


            if (isLetterOnTile(letter, tilesArrayRed)) {
                return true; // Если буква из слова найдена на красной фишке, вернуть true
            }
        }
        return false; // Если ни одна буква не найдена на красной фишке, вернуть false
    }
    private boolean isWordDouble(String word, TextView[][] tilesArrayPink) {
        for (int i = 0; i < word.length(); i++) {
            char letter = Character.toUpperCase(word.charAt(i));


            if (isLetterOnTile(letter, tilesArrayPink)) {
                return true; // Если буква из слова найдена на красной фишке, вернуть true
            }
        }
        return false; // Если ни одна буква не найдена на красной фишке, вернуть false
    }
    private void showEndDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.endgame_dialog);
        int FinalScore1 = totalScorePlayer1;
        int FinalScore2 = totalScorePlayer2;
        int WinPlayer;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(lp);
        TextView EndDialogScoreTextView = dialog.findViewById(R.id.EndDialogScoreTextView);
        TextView WinDialogMessageTextView = dialog.findViewById(R.id.WinDialogMessageTextView);
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT); // Растягивает окно на весь экран
        Button endOkButton = dialog.findViewById(R.id.endOkButton);
        ScoreDatabaseHelper dbHelper = new ScoreDatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ScoreDatabaseHelper.COLUMN_PLAYER_1_SCORE, totalScorePlayer1);
        values.put(ScoreDatabaseHelper.COLUMN_PLAYER_2_SCORE, totalScorePlayer2);
// Вставьте данные в базу данных
        long newRowId = db.insert(ScoreDatabaseHelper.TABLE_SCORES, null, values);
// Закройте базу данных
        db.close();
        EndDialogScoreTextView.setText("Счёт игрока 1:" + FinalScore1 + "       Счёт игрока 2:" + FinalScore2);
        if (FinalScore1 > FinalScore2){
            WinPlayer = 1;
        } else {
            WinPlayer = 2;
        }
        if (FinalScore1 != FinalScore2) {
            WinDialogMessageTextView.setText("Победил игрок: " + WinPlayer);
        } else {
            WinDialogMessageTextView.setText("Ничья");
        }

        endOkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra("player1Score", totalScorePlayer1);
                intent.putExtra("player2Score", totalScorePlayer2);
                setResult(RESULT_OK, intent);


                setResult(RESULT_OK, intent);


// Закрываем SecondActivity
                finish(); // Закрыть диалоговое окно при нажатии кнопки "ОК"
            }
        });

        dialog.show();
    }
    private void showPlayerTurnDialog(int currentPlayer) {

        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.nextmove_dialog);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(lp);

        TextView messageTextView = dialog.findViewById(R.id.dialogMessageTextView);
        if (currentPlayer == 1){
            messageTextView.setText("Ход игрока: 2");
        }
        if (currentPlayer == 2){
            messageTextView.setText("Ход игрока: 1");
        }
        // Убирает фон окна
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT); // Растягивает окно на весь экран
        Button okButton = dialog.findViewById(R.id.dialogOkButton);

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss(); // Закрыть диалоговое окно при нажатии кнопки "ОК"
            }
        });

        dialog.show();
    }
    private boolean isInTilesArrayBlue(TextView tile) {
        for (int i = 0; i < tilesArrayBlue.length; i++) {
            for (int j = 0; j < tilesArrayBlue[i].length; j++) {
                if (tilesArrayBlue[i][j] == tile) {
                    return true; // Фишка принадлежит tilesArray
                }
            }
        }
        return false; // Фишка не принадлежит tilesArray
    }
    private boolean isInTilesArrayPink(TextView tile) {
        for (int i = 0; i < tilesArrayPink.length; i++) {
            for (int j = 0; j < tilesArrayPink[i].length; j++) {
                if (tilesArrayPink[i][j] == tile) {
                    return true; // Фишка принадлежит tilesArray
                }
            }
        }
        return false; // Фишка не принадлежит tilesArray
    }
    private boolean isInTilesArrayRed(TextView tile) {
        for (int i = 0; i < tilesArrayRed.length; i++) {
            for (int j = 0; j < tilesArrayRed[i].length; j++) {
                if (tilesArrayRed[i][j] == tile) {
                    return true; // Фишка принадлежит tilesArray
                }
            }
        }
        return false; // Фишка не принадлежит tilesArray
    }
    private boolean isInTilesArrayDarkBlue(TextView tile) {
        for (int i = 0; i < tilesArrayDarkBlue.length; i++) {
            for (int j = 0; j < tilesArrayDarkBlue[i].length; j++) {
                if (tilesArrayDarkBlue[i][j] == tile) {
                    return true; // Фишка принадлежит tilesArray
                }
            }
        }
        return false; // Фишка не принадлежит tilesArray
    }

    private class TileTouchListener implements View.OnTouchListener {
        @Override

        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                TextView tile = (TextView) v;

                if (tile.getText() == null || tile.getText().toString().isEmpty() || isTileInWordTiles(tile,wordTiles )) {
                    return false; // Запретить перемещение пустой фишки
                }


                draggedTile = tile;
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(v);
                v.startDrag(null, shadowBuilder, v, 0);
                v.setVisibility(View.INVISIBLE);
                return true;
            }
            return false;
        }
    }
    private boolean areNonWordTilesPresent() {
        for (int i = 0; i < gridLayout.getChildCount(); i++) {
            View child = gridLayout.getChildAt(i);
            if (child instanceof TextView) {
                TextView tile = (TextView) child;
                if (!wordTiles.contains(tile) && !TextUtils.isEmpty(tile.getText())) {
                    // Если фишка не принадлежит wordTiles и заполнена текстом, вернуть true
                    return true;
                }
            }
        }
        // Если не было найдено букв, не принадлежащих wordTiles, вернуть false
        return false;
    }
    private boolean isTileInGrid(View tile) {
        return tile.getParent() == findViewById(R.id.grid_layout);
    }
    public boolean isNotEmpty(){
        for (TextView tile : letterTiles) {
            if (tile.getText() == null || tile.getText().toString().isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private class TileDragListener implements View.OnDragListener {

        @Override
        public boolean onDrag(View v, DragEvent event) {
            TextView tile = (TextView) v;

            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    return true;

                case DragEvent.ACTION_DRAG_ENTERED:
                    tile.setBackgroundResource(R.drawable.tile_background_highlighted);
                    return true;
                case DragEvent.ACTION_DRAG_EXITED:
                    TextView targetTile = (TextView) v;
                    Drawable background = tile.getBackground();
                    if (isInTilesArrayBlue(tile)) {
                        tile.setBackgroundResource(R.drawable.tile_background_blue);
                    } else if (isInTilesArrayPink(tile)) {
                        tile.setBackgroundResource(R.drawable.tile_background_pink);
                    } else if (isInTilesArrayRed(tile)) {
                        tile.setBackgroundResource(R.drawable.tile_background_red);
                    } else if (isInTilesArrayDarkBlue(tile)) {
                        tile.setBackgroundResource(R.drawable.tile_background_darkblue);
                    } else if (!(TextUtils.isEmpty(tile.getText())) || !(isTileInGrid(tile))) {
                        return false;
                    } else
                        tile.setBackgroundResource(R.drawable.tile_background);


                    return true;
                case DragEvent.ACTION_DROP:
                    if (v != null) {

                        if (!(wordTiles.contains(tile))) {
                            CharSequence draggedLetter = draggedTile.getText();
                            CharSequence targetLetter = tile.getText();
                            draggedTile.setText(targetLetter);
                            tile.setText(draggedLetter);
                            draggedTile.setVisibility(View.VISIBLE);
                        } else {
                            // Вернуть фишку на место, если она принадлежит wordTiles
                            draggedTile.setVisibility(View.VISIBLE);
                            wordTiles.add(tile);
                        }


                    return true;
            } else {
                        return false;

                    }

                case DragEvent.ACTION_DRAG_ENDED:

                    if (!event.getResult()) {
                        draggedTile.setVisibility(View.VISIBLE);
                    } else
                    if (isInTilesArrayBlue(tile)) {
                        tile.setBackgroundResource(R.drawable.tile_background_blue);
                    } else
                    if (isInTilesArrayPink(tile)) {
                        tile.setBackgroundResource(R.drawable.tile_background_pink);
                    } else
                    if (isInTilesArrayRed(tile)) {
                        tile.setBackgroundResource(R.drawable.tile_background_red);
                    } else
                    if (isInTilesArrayDarkBlue(tile)) {
                        tile.setBackgroundResource(R.drawable.tile_background_darkblue);
                    } else
                    if (TextUtils.isEmpty(tile.getText()) && isTileInGrid(tile)) {
                        tile.setBackgroundResource(R.drawable.tile_background);
                    }

                    if (areNonWordTilesPresent()) {
                        checkButton.setVisibility(View.VISIBLE);
                        replaceLettersButton.setVisibility(View.INVISIBLE);

                    } else {
                        checkButton.setVisibility(View.INVISIBLE);
                        replaceLettersButton.setVisibility(View.VISIBLE);

                    }

                    return true;
                default:
                    return false; }

        }
    }
}

